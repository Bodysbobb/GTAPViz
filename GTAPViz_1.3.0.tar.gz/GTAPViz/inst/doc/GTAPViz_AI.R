## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(eval = FALSE)

## -----------------------------------------------------------------------------
# install.packages("remotes")
# remotes::install_github("Bodysbobb/GTAPViz")   # the AI feature needs GTAPViz 1.3.0 or later
# GTAPViz::mcp_install()                         # Claude Desktop

## -----------------------------------------------------------------------------
# GTAPViz::mcp_install("claude_code")   # Claude Code (all projects)
# GTAPViz::mcp_install("cursor")        # Cursor
# GTAPViz::mcp_install("other")         # prints settings to paste into any MCP app

## -----------------------------------------------------------------------------
# library(GTAPViz)
# 
# # ---- Step 1: Load GTAP results (EXP1, EXP2) ----
# input_path <- "D:/TradeWar/in"
# output_path <- "D:/TradeWar/out"
# auto_gtap_data(
#   experiment = c("EXP1", "EXP2"),
#   input_path = input_path,
#   har_suffix = "-WEL",
#   mapping_info = "GTAPv7",
#   plot_data = TRUE
# )
# 
# # ---- Step 2: comparison_plot of sl4.plot.data[["REG"]] (EV, qgdp) ----
# comparison_plot(
#   data = sl4.plot.data[["REG"]],
#   filter_var = list(Variable = c("EV", "qgdp")),
#   x_axis_from = "Region",
#   output_path = output_path,
#   export_picture = TRUE,
#   plot_style_config = create_plot_style(color_tone = "purdue")
# )

